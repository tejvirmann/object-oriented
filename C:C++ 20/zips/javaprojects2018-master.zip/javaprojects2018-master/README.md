# javaprojects2018
Here are two Java based games and one Parser tool (which parses text files) 

You can run these games/parsers using Eclipse or IntelliJ if you want to try them out. 
