# angularlist
Using simple AngularJS and HTML I made a list that updates every time you add to it. 
