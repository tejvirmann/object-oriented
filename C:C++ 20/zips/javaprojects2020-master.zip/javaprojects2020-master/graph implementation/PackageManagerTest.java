


import static org.junit.jupiter.api.Assertions.fail;

import org.junit.jupiter.api.Test;

public class PackageManagerTest {
	
	   /** IMPLEMENTED AS EXAMPLE FOR YOU
  * Tests that a HashTable is empty upon initialization
  */
 @Test
 public void test000_collision_scheme() {

         fail("collision resolution must be indicated with 1-10");
 }

}
